
<!-- Configuration-->

<?php require_once("../resources/config.php"); ?>

<?php 
$value;



error_reporting(E_ALL & ~E_NOTICE);
if (isset($_GET['add'])) { //Adding 1 more to product quantity
    
    $query = query("SELECT * FROM products WHERE IDproduct=" . escape_string($_GET['add']) . " ");
    confirm($query);

    while($row = fetch_array($query)){
        if ($row['productQuantity'] != $_SESSION['product_' . $_GET['add']]) {
            $_SESSION['product_' . $_GET['add']] +=1;
            redirect("checkout.php");

        }else {
            setmessage("We only have " . $row['productQuantity'] . " " . $row['productName'] . " available");
            redirect("checkout.php");
        }
    }

}

if (isset($_GET['remove'])) { //removing 1 from product quantity
    $_SESSION['product_' . $_GET['remove']]--;
    if ($_SESSION['product_' . $_GET['remove']]<1) {
        unset($_SESSION['itemTotal']);
        unset($_SESSION['itemQuantity']);
        redirect("checkout.php");
    }else {
        redirect("checkout.php");
    }
}

if (isset($_GET['delete'])) { //removing item from the cart
    $_SESSION['product_' . $_GET['delete']] = '0';
    unset($_SESSION['itemTotal']);
    unset($_SESSION['itemQuantity']);
    redirect("checkout.php");

}

function cart() {
//Controls the cart functionality of the website
    $total = 0;
    $itemQuantity = 0;
    
        foreach ($_SESSION as $name => $value) {
            if ($value > 0) {
    
    if(substr($name, 0, 8) == "product_"){ 
    $length = strlen($name) - 8;
    $id = substr($name, 8, $length);
    
                    $query = query("SELECT * FROM products WHERE IDproduct = " . escape_string($id) . " "); //Calls products with specific ids
                    confirm($query);
                    while ($row = fetch_array($query)) {
                        $productImage = showImage($row['productImage']);
    $sub = $row['productPrice'] * $value; 
    $itemQuantity += $value;
    $product = <<<DELIMETER
                    
<tr>
<td>{$row['productName']}</td>
<td>R{$row['productPrice']}</td>
<td>{$value}</td>
<td>R$sub</td>
<td><img class = "item" width='150' src="../resources/$productImage"</td>
<td>
    <a class = 'btn btn-warning' href="cart.php?remove={$row['IDproduct']}"><span class = 'glyphicon glyphicon-minus'></span></a>
    <a class = 'btn btn-success' href="cart.php?add={$row['IDproduct']}"><span class = 'glyphicon glyphicon-plus'></span></a>
    <a class = 'btn btn-danger' href="cart.php?delete={$row['IDproduct']}"><span class = 'glyphicon glyphicon-remove'></span></a>
</td>

</tr>
                    
DELIMETER;
    echo $product;
    
    
                   }
     $_SESSION['itemTotal'] = $total += $sub;
     $_SESSION['itemQuantity'] = $itemQuantity;
     
                }
            }
        }
    }

function reports() {
//Adds new reports to the database after a order has been made
    $total = 0;
    $itemQuantity = 0;
    
        foreach ($_SESSION as $name => $value) {
            if ($value > 0) {
    
    if(substr($name, 0, 8) == "product_"){
    $length = strlen($name) - 8;
    $id = substr($name, 8, $length); 
    
                    $query = query("SELECT * FROM products WHERE IDproduct = " . escape_string($id) . " ");
                    confirm($query);
                    while ($row = fetch_array($query)) {
                        $productPrice = $row['productPrice'];
                        
    $sub = $row['productPrice'] * $value;
    $itemQuantity += $value;
    
  
    $report = query("INSERT INTO reports (IDproduct, productPrice, productQuantity) VALUES ('{$id}','{$productPrice}','{$value}')");
    confirm($report);
    
                   }
$total += $sub;
$itemQuantity;
                }
            }
        }
    }
?>
