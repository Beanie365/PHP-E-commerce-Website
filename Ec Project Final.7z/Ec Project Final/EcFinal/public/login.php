<?php require_once("../resources/config.php"); ?>
<!DOCTYPE html>
<html lang="en">
<title>Login</title>
<?php include(TEMPLATE_FRONT . DS . "header.php") ;

?>
<link href="css/login.css" rel="stylesheet">
    <!-- Page Content -->
    <div class="container" id = "login">
        <div>

      <header>
            <h1 class="text-center">Login</h1>
            <h2 class = "text-center bg-warning"><?php displayMsg(); ?></h2>
        <div class="col-sm-4 col-sm-offset-5">         
            <form class="" action="" method="post" enctype="multipart/form-data">
            <?php //Calls function for logging in users
             loginCust(); 
            ?>
                <div class="form-group"><label for="">
                    Username<input type="text" name="username" class="form-control"></label>
                </div>
                 <div class="form-group"><label for="password">
                    Password<input type="password" name="password" class="form-control"></label>
                </div>

                <div class="form-group">
                  <input type="submit" name="submit" class="btn btn-primary" >
                </div>
                Not a member? <a href="register.php">Create an Account</a>
            </form>
        </div>  


    </header>


        </div>
    </div>
    </div>
    <!-- /.container -->

    <?php include(TEMPLATE_FRONT . DS . "footer.php") ?>