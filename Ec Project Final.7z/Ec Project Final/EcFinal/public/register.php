<?php require_once("../resources/config.php"); ?>
<!DOCTYPE html>
<html lang="en">
<title>Register</title>
<div>
<?php include(TEMPLATE_FRONT . DS . "header.php") ?>
<link href="css/register.css" rel="stylesheet">
<?php //echo $_SESSION['user']; ?>
	<h2 class = "text-center">Register</h2>
</div id = "register">
<div class= "container text-center">
<form class = "" method="post" action="register.php">

	<div class="form-group">
    <h2><?php displayMsg();?></h2><br>
		<label>Username</label>
		<div><input type="text" name="username" value="" class="form-control"> </div>
	</div>
	
	<div class="form-group">
		<label>Email</label>
		<div>	<input type="email" name="email" value="" class="form-control"></div>
	</div>
	<div class="form-group">
		<label>Password</label>
		<div>	<input type="password" name="password_1" class="form-control"></div>
	</div>
	<div class="form-group">
		<label>Confirm password</label>
		<div>	<input type="password" name="password_2" class="form-control"></div>
	</div>
	
	
	<div class="form-group">
		<button type="submit" class="btn btn-primary" name="register_btn">Register</button>
    </div>
    
	<p>
		Already a member? <br><a class="btn btn-warning" href="login.php">Sign in</a>
	</p>
</form>
</div>
<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>
</div>