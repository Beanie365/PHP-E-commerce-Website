<?php require_once("../resources/config.php"); ?>
<!DOCTYPE html>
<html lang="en">
<title>Shop</title>
<?php include(TEMPLATE_FRONT . DS . "header.php") ?>

<?php include(TEMPLATE_FRONT . DS . "navside.php") ?>
    <!-- Page Content -->
    <div class="container">

        <!-- Jumbotron Header -->
        <header class="">
            <h1>Product List</h1>
            
        </header>

        <!-- Page Features -->
        <div class="row text-center">
            <?php //Gets all products
            get_shopitems();
            ?>

            
            

        </div>
        <!-- /.row -->

       

    </div>
    <!-- /.container -->

    <?php include(TEMPLATE_FRONT . DS . "footer.php") ?>