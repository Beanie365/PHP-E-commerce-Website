<?php require_once("../resources/config.php"); ?>
<!DOCTYPE html>
<html lang="en">
<title>Help</title>
<div>
<?php include(TEMPLATE_FRONT . DS . "header.php") ?>
<h1 class= "text-center">Welcome To our Help Section</h1>

<div class= "container">

<div class= "row">

<div> <h2>FAQ </h2><br>

<p>Why can't I enter my cart? <br>


You need to login first! This way we can keep track of our customers.
<br>
</p>
<p>
Do you stock "this item"? <br>

If you don't see any item you're looking for, we do not have it, unfortunately. You are welcome to contact us if you're interested in seeing an item at our store. <br>
</p>

<p>How do I contact you?
<br>

You can send us a message <a href="contact.php">here</a> or email the owner at achilles27@gmail.com

</p>
<p> An advanced help manual will be here soon. Please be patient while we build it up! <span class= "glyphicon glyphicon-star"> </span> </p>

</div>

</div>



</div>




<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>