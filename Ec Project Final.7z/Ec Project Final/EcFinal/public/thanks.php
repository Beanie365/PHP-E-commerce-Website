<!-- Configuration-->

<?php require_once("../resources/config.php"); ?>
<?php require_once("cart.php"); ?>

<!-- Header-->
<?php include(TEMPLATE_FRONT .  "/header.php"); ?>
<?php
error_reporting(E_ALL & ~E_NOTICE);
?>
<!-- Page Content -->
<div class="container">

    <div class="row">
        <h4 class="text-center bg-danger"><?php displayMsg(); ?></h4>
        <h1>Thank you for your Purchase!</h1>

        <?php
        //Adds a new report to the database
        reports();

        //Destroys the session to clear the cart. Unfortunately this logs the user out
        session_destroy(); ?>


    </div>

    <?php include(TEMPLATE_FRONT .  "/footer.php"); ?>