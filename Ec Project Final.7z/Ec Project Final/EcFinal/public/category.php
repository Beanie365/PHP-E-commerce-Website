<?php require_once("../resources/config.php"); ?>
<!DOCTYPE html>
<html lang="en">
<title>Category</title>
<?php include(TEMPLATE_FRONT . DS . "header.php") ?>
<?php include(TEMPLATE_FRONT . DS . "navside.php") ?>
    <!-- Page Content -->
    <div class="container">

        <!-- Jumbotron Header -->
        
            <h1>Category Page </h1>
            <p>Browse our Latest Products</p>
            
            </p>

        <!-- Title -->
        <div class="row">
            <div class="col-lg-12">
                <h3>Latest Features</h3>
            </div>
        </div>
        <!-- /.row -->

        <!-- Page Features -->
        <div class="row text-center">
            <?php //function to call category items according to their category type
            get_catitems();
            ?>

        </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->

    <?php include(TEMPLATE_FRONT . DS . "footer.php") ?>