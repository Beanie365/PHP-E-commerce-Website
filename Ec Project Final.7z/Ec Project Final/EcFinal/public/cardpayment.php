<?php require_once("../resources/config.php"); ?>
<!DOCTYPE html>
<html lang="en">
<title>Payment</title>
<?php include(TEMPLATE_FRONT . DS . "header.php");
//function to add new orders to the database
orderAdd();

?>

<div class="container">
    <div class="row">
        
        <div class="col-xs-12 col-md-4">
                        <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        Payment Details
                    </h3>
                    <div class="checkbox pull-right">
                       
                    </div>
                </div>
                <div class="panel-body">
                    <form role="form">
                    <div class="form-group">
                        <label for="cardNumber">
                            CARD NUMBER</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="cardNumber" name="cardnumber" id="cardnumber" placeholder="Valid Card Number"
                                required autofocus />
                            <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-7 col-md-7">
                            <div class="form-group">
                                <label for="expityMonth">
                                    EXPIRY DATE</label>
                                <div class="col-xs-6 col-lg-6 pl-ziro">
                                    <input type="text" class="form-control" id="expiryMonth" name= "expiryMonth" placeholder="MM" required />
                                </div>
                                <div class="col-xs-6 col-lg-6 pl-ziro">
                                    <input type="text" class="form-control" id="expiryYear" name ="expiryYear" placeholder="YY" required /></div>
                            </div>
                        </div>
                        <div class="col-xs-5 col-md-5 pull-right">
                            <div class="form-group">
                                <label for="cvCode">
                                    CV CODE</label>
                                <input type="password" class="form-control" id="cvCode" name="cvcode" placeholder="CV" required />
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
            <ul class="nav nav-pills nav-stacked">
                <li class="active"><span class="glyphicon glyphicon-R"></span><?php echo "Final Payment R" . $_SESSION['itemTotal'] ?>
                </li>
            </ul>
            <br/>
            
        </div>
        <div class="container">
	<div class="row">
		 <form class="form-horizontal" method="post">
            <fieldset>
                <!-- Address form -->
         
                <h2>Address</h2>
         
                <!-- full-name input-->
                <div class="control-group">
                    <label class="control-label">Full Name</label>
                    <div class="controls">
                        <input id="fullname" name="fullname" type="text" placeholder="full name"
                        class="input-xlarge">
                        <p class="help-block"></p>
                    </div>
                </div>
                <!-- address-line1 input-->
                <div class="control-group">
                    <label class="control-label">Address </label>
                    <div class="controls">
                        <input id="address" name="address" type="text" placeholder="address line"
                        class="input-xlarge">
                        <p class="help-block">Enter Your Address</p>
                    </div>
                </div>
               <div class = "control-group"> <input type="submit" name="paybtn" class="btn btn-primary btn-lg text-center" value="Pay"></div>
                    
                </div>
            </fieldset>
        </form>
        
    </div>
    
</div>
    </div>
    
    
</div>
