<?php require_once("../../resources/config.php"); ?>
<?php include(TEMPLATE_BACK . "/header.php"); ?>


<?php if(!isset($_SESSION['username'])){
    
    redirect("../../public/");


} 
if($_SESSION['username']!='admin'){
    redirect("../../public/");
}
?>


<div id="page-wrapper">

    <div class="container-fluid">



        <?php //Function to add a category to the database 
        addCatAdmin(); ?>

        <h1 class="page-header">
            Product Categories

        </h1>
        <h3><?php displayMsg(); ?></h3>

        <div class="col-md-4">

            <form action="" method="post">

                <div class="form-group">
                    <label for="catTitle">Title</label>
                    <input name="catTitle" type="text" class="form-control">
                </div>

                <div class="form-group">

                    <input name="addCat" type="submit" class="btn btn-primary" value="Add Category">
                </div>


            </form>


        </div>


        <div class="col-md-8">

            <table class="table">
                <thead>

                    <tr>
                        <th>id</th>
                        <th>Title</th>
                    </tr>
                </thead>


                <tbody>
                    <?php //function to show the different categories in the database
                     catAdmin(); ?>
                </tbody>

            </table>

        </div>




    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

</div>
<?php include(TEMPLATE_BACK . "/footer.php") ?>