<?php require_once("../../resources/config.php"); ?>
<?php include(TEMPLATE_BACK . "/header.php");?>
<?php if(!isset($_SESSION['username'])){
    
    redirect("../../public/");


} 
if($_SESSION['username']!='admin'){
    redirect("../../public/");
}
?>

        <div id="page-wrapper">

            <div class="container-fluid">

             <div class="row">

<h1 class="page-header">
   All Products

</h1>
<h3><?php displayMsg(); 
?></h3>
<table class="table table-hover">


    <thead>

      <tr>
           <th>Id</th>
           <th>Title</th>
           <th>Category</th>
           <th>Price</th>
           <th>Quantity Available</th>
      </tr>
      <?php //function to show all products in the database
      adminProducts(); ?>
    </thead>
    <tbody>

      
      


  </tbody>
</table>











                
                 


             </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->







    </div>
    <?php include(TEMPLATE_BACK . "/footer.php") ?>