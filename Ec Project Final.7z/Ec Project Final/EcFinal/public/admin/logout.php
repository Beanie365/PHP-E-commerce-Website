<?php
//logs user out of the current session
session_start();
session_destroy();
unset($_SESSION['user']);
header("Location: ../../public");

?>