

<?php require_once("../../resources/config.php"); ?>
<?php include(TEMPLATE_BACK . "/header.php");?>
<?php if(!isset($_SESSION['username'])){
    
    redirect("../../public/");


} 
if($_SESSION['username']!='admin'){
    redirect("../../public/");
}
?>
        <div id="page-wrapper">

            <div class="container-fluid">


                


        <div class="col-md-12">
<div class="row">
<h1 class="page-header">
   All Orders

</h1>
</div>

<div class="row">
<table class="table table-hover">
    <thead>

      <tr>
           <th>Order ID</th>
           <th>User</th>
           <th>Full Name</th>
           <th>Status</th>
           <th>Order Total</th>
           <th>Address</th>
                 </tr>
    </thead>
    <tbody>
      <?php //function to show all orders in the database
      ordersAdmin(); ?>
        

    </tbody>
</table>
</div>

<div class="row">
<table class="table table-hover">
    <thead>

      <tr>
           <th>Report ID</th>
           <th>Product ID</th>
           <th>Product Price</th>
           <th>Product Quantity</th>
           
                 </tr>
    </thead>
    <tbody>
      <?php //function to show all reports in the database
      reportsAdmin(); ?>
        

    </tbody>
</table>
</div>











            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <?php include(TEMPLATE_BACK . DS . "/footer.php") ?>