<?php require_once("../../resources/config.php"); ?>
<?php include(TEMPLATE_BACK . "/header.php"); ?>
<?php if(!isset($_SESSION['username'])){
    
    redirect("../../public/");


} 
if($_SESSION['username']!='admin'){
    redirect("../../public/");
}
?>

<div id="page-wrapper">

    <div class="container-fluid">



        <div class="col-lg-12">


            <h1 class="page-header">
                Users

            </h1>
            <p class="bg-success">

            </p>
            <div class="col-md-12">

                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Username</th>
                            <th>Email</th>

                        </tr>
                    </thead>
                    <tbody>

                        <?php //Function to show all users in the database
                        userAdmin();  ?>


                        <?php  ?>

                    </tbody>
                </table>
                <!--End of Table-->


            </div>


        </div>


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->
<?php include(TEMPLATE_BACK . "/footer.php") ?>