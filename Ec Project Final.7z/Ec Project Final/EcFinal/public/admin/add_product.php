<?php require_once("../../resources/config.php"); ?>
<?php include(TEMPLATE_BACK . "/header.php"); 
//Page to add products to the system through the admin area

?>
<?php if(!isset($_SESSION['username'])){
    
    redirect("../../public/");


} 
if($_SESSION['username']!='admin'){
    redirect("../../public/");
}
?>
<link href="css/sb-admin.css" rel="stylesheet">
<div id="page-wrapper">

  <div class="container-fluid">






    <div class="col-md-12">

      <div class="row">
        <h1 class="page-header">
          Add Product
          <?php //calls The functions to add products
          addProduct(); ?>
        </h1>
      </div>



      <form action="" method="post" enctype="multipart/form-data">


        <div class="col-md-8">

          <div class="form-group">
            <label for="productName">Product Name </label>
            <input type="text" name="productName" class="form-control">

          </div>


          <div class="form-group">
            <label for="productDesc">Product Description</label>
            <textarea name="productDesc" id="" cols="30" rows="10" class="form-control"></textarea>
          </div>



          <div class="form-group row">

            <div class="col-xs-3">
              <label for="productPrice">Product Price</label>
              <input type="number" name="productPrice" class="form-control" size="60">
            </div>
          </div>




          <!-- Product Categories-->

          <div class="form-group">
            <label for="productCate">Product Category</label>

            <select class="form-control" name=productCate>
              <option value="">Select Category</option>
              <?php //calls the function to show categories 
              showCatAdmin(); ?>

            </select>


          </div>
          <div class="form-group">
            <label for="productQuantity">Product Quantity</label>
            <input type="number" class="form-control" name=productQuantity>
          </div>
          <div class="form-group">
            <label for="productCaption">Product Caption</label>

            <input type="text" name="productCaption" class="form-control">
          </div>

          <!-- Product Image -->
          <div class="form-group">
            <label for="productImage">Product Image</label>
            <input type="file" name="file">

          </div>
          <div class="form-group">

            <input type="submit" name="publish" class="btn btn-primary btn-lg" value="Add to List">
          </div>



        </div>


        <aside id="admin_sidebar" class="col-md-4">


        </aside>
      
      </form>



    </div>
    <!-- /.container-fluid -->

  </div>
  <!-- /#page-wrapper -->
  <?php include(TEMPLATE_BACK . "/footer.php") ?>