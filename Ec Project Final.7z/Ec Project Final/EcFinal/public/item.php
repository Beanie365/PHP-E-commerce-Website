<?php require_once("../resources/config.php"); ?>
<?php include(TEMPLATE_FRONT . DS . "header.php"); ?>
<title>Item Page</title>
<?php include(TEMPLATE_FRONT . DS . "navside.php") ?>
<div class="container">

            <?php //Shows specific item details
            
            $query =  query("SELECT * FROM products WHERE IDproduct = " . escape_string($_GET['id']) . " ");

            confirm($query);
        
            while ($row = fetch_array($query)):
                
            
            ?>
<div class="col-md-9">

<!--Row For Image and Short Description-->

<div class="row">

    <div class="col-md-7">
       <img class="img-responsive" src="../resources/<?php echo showImage($row['productImage']); ?>" alt="">

    </div>

    <div class="col-md-5">

        <div class="thumbnail">
         

    <div class="caption-full">
        <h4><?php echo $row['productName']; ?></h4>
        <hr>
        <h4 class=""><?php echo "&#82;" . $row['productPrice'];?></h4>
  
        <p><?php echo  $row['productCaption']; ?></p>

   
    <form action="">
        <div class="form-group">
        <a class="btn btn-primary" target="_blank" href="cart.php?add=<?php echo $row['IDproduct'];?>">Add to Cart</a>
        </div>
    </form>

    </div>
 
</div>

</div>


</div>


<div class="row">

<div role="tabpanel">

  <!-- Nav tabs -->
  <ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Description</a></li>
    

  </ul>

  <!-- Tab panes -->
  <div class="tab-content">
    <div role="tabpanel" class="tab-pane active" id="home">

<p></p>
           
    <p><p><?php echo  $row['productDesc']; ?></p> <p>

    </div>
    <div role="tabpanel" class="tab-pane" id="profile">


</div><!--Row for Tab Panel-->

<?php
endwhile;
?>


</div>

<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>


