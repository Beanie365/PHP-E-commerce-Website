<?php require_once("../resources/config.php"); ?>
<!DOCTYPE html>
<html lang="en">
<title>FA's Home Page</title>
<?php include(TEMPLATE_FRONT . DS . "header.php") ;

?>


<!-- Page Content -->
<div class="container">

    <div class="row">

        <!--Categories -->
        <?php include(TEMPLATE_FRONT . DS . "navside.php") ?>

        <div class="col-md-9">

            

            <div class="row">


                          <?php
//Calls all products from the database
                get_products();
                ?>

                
            </div> <!-- Row end -->

        </div>

    </div>

</div>
<!-- /.container -->

<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>