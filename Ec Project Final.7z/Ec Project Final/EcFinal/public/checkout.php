
<!-- Configuration-->

<?php require_once("../resources/config.php"); ?>
<?php require_once("cart.php"); ?>
<title>Checkout</title>
<!-- Header-->
<?php include(TEMPLATE_FRONT .  "/header.php");?>
<?php 
if (!isLoggedIn()) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}
?>
    <!-- Page Content -->
    <div class="container">


<!-- /.row --> 

<div class="row">
<h4 class = "text-center bg-danger"><?php displayMsg(); ?></h4>
      <h1>Checkout</h1>

<form action="">
    <table class="table table-striped">
        <thead>
          <tr>
           <th>Product</th>
           <th>Price</th>
           <th>Quantity</th>
           <th>Sub-total</th>
           <th>Preview</th>
     
          </tr>
        </thead>
        <tbody>

        <?php //calls the cart functionality
        cart(); ?>
        </tbody>
    </table>
</form>

<!--  ***********CART TOTALS*************-->
            
<div class="col-xs-4 pull-right ">
<h2>Cart Totals</h2>

<table class="table table-bordered" cellspacing="0">

<tr class="cart-subtotal">
<th>Items:</th>
<td><span class="amount">
    <?php 
        echo isset($_SESSION['itemQuantity']) ? $_SESSION['itemQuantity'] : $_SESSION['itemQuantity'] = 0;
    ?></span></td>
</tr>
<tr class="shipping">
<th>Shipping and Handling</th>
<td>Free Shipping</td>
</tr>

<tr class="order-total">
<th>Order Total</th>
<td><strong><span class="amount">R 
    <?php 
        echo isset($_SESSION['itemTotal']) ? $_SESSION['itemTotal'] : $_SESSION['itemTotal'] = 0;
    ?></span></strong> </td>
</tr>


</tbody>

</table>


<?php

if(isset($_SESSION['itemTotal'])&& ($_SESSION['itemTotal']===0)){
    $pay = <<<DELIMITER
    <h2>No items in cart... <?h2>
DELIMITER;
    echo $pay;
    
}else{
    $pay = <<<DELIMITER
    <h4>Proceed to Payment</h4>
<a class="btn btn-primary" target="_blank" href="cardpayment.php">Credit/Debit Card</a><br>
<br>

<a class="btn btn-primary" target="_blank" href="thanks.php">Cash on Delivery</a><br>
DELIMITER;
echo $pay;
}
?>
</div>
 </div>


           <hr>

           <?php include(TEMPLATE_FRONT .  "/footer.php");?>

    </div>


 <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
