<?php require_once("../../config.php"); ?>
 <?php
 
 
 if(isset($_GET['id'])){
     $query = query("DELETE FROM products WHERE IDproduct = " . escape_string($_GET['id']));
 confirm($query);
  

 setMessage("Product Deleted.");
 redirect("../../../public/admin/products.php");
    }

    else{{
        redirect("../../../public/admin/products.php"); 
    }}

?>