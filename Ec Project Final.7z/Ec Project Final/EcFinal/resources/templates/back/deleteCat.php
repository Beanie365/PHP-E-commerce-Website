<?php require_once("../../config.php"); ?>
 <?php
 
  if(isset($_GET['id'])){
     $query = query("DELETE FROM categories WHERE IDcat = " . escape_string($_GET['id']));
 confirm($query);
  

 setMessage("Category Deleted.");
 redirect("../../../public/admin/categories.php");
    }

    else{{
        redirect("../../../public/admin/categories.php"); 
    }}

?>