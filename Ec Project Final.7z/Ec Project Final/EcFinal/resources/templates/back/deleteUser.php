<?php require_once("../../config.php"); ?>
 <?php
 
  if(isset($_GET['id'])){
     $query = query("DELETE FROM users WHERE IDuser = " . escape_string($_GET['id']));
 confirm($query);
  

 setMessage("User Deleted.");
 redirect("../../../public/admin/index.php?users");
    }

    else{{
        redirect("../../../public/admin/index.php?users"); 
    }}

?>