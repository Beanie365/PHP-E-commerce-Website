<div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    
                    <li>
                    <a class="navbar-brand" href="products.php">FA's Admin Zone</a>
                    </li>
                    <li>
                    <a class="navbar-brand" href="../index.php">Shop Home</a>
                    </li>
                    
                    
                
                </ul>
            </div>