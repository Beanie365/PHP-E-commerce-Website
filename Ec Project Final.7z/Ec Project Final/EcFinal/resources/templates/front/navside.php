<div class="col-md-3">
    <p class="lead">FA's Spray And Restoration</p>
    <div class="list-group">

        <?php

        get_categories();

        
        ?>


    </div>
</div>