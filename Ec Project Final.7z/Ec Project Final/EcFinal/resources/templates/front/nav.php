<div class="container">

            <div>
                <ul class="nav navbar-nav ">
                    <li>
                <a class="navbar-brand" href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="shop.php">Shop</a>
                    </li>
                    <li>
                        <a href="login.php">Login</a>
                    </li>
                    <li>
                    <?php
                if(isset($_SESSION['username'])&& $_SESSION['username']==='admin'){
                    $admin = <<<DELIMITER
                

                <a href= "admin/products.php">Admin</a>

DELIMITER;
echo $admin;
}else{
    $admin = <<<DELIMITER

<h4> </h4>    

DELIMITER;
echo $admin;
}
                ?>
                    </li>
                     <li>
                        <a href="checkout.php">Checkout</a>
                    </li>
                    <li>
                        <a href="contact.php">Contact</a>
                    </li>
                    

                </ul>
                <?php
                if(isset($_SESSION['user'])){
                    $logout = <<<DELIMITER
                

                <h5><a href="logout.php" class = "nav navbar-nav pull-right"><i class="fa fa-fw fa-power-off"></i> Log Out</a></h5>

DELIMITER;
echo $logout;
}
                ?>
            </div>
           
        </div>
