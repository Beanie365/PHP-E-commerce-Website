<?php

//Most of the functions used in the website
$images = "images";
$errors   = array();
function setMessage($msg)
{
//Sets messages to be displayed in any place. Uses displayMsg() to display the message.
    if (!empty($msg)) {
        $_SESSION['message'] = $msg;
    } else {

        $msg = "";
    }
}
function displayMsg()
{//Used by setMessage()
    if (isset($_SESSION['message'])) {
        echo $_SESSION['message'];
        unset($_SESSION['message']);
    }
}

function redirect($location)
{
    //redirects user to specified page

    header("Location: $location");
}

function query($sql)
{
//Queries the specified SQL and returns the results of the query
    global $connection;
    return mysqli_query($connection, $sql);
}

function confirm($result)
{//provides info on failed queries
    global $connection;
    if (!$result) {
        die("QUERY FAILED" . mysqli_error($connection));
    }
}

function escape_string($string)
{//prevents SQL Injection
    global $connection;
    return mysqli_real_escape_string($connection, $string);
}

function fetch_array($result)
{//fetches rows of data from a Database
    return mysqli_fetch_array($result);
}


//Front end Functions
//get products

function get_products()
{//Gets the products from the products table in the database and displays it
    $query =  query("SELECT * FROM products");

    confirm($query);

    while ($row = fetch_array($query)) {

        $productImage = showImage($row['productImage']);
        $products = <<<DELIMITER
<div class="col-sm-4 col-lg-4 col-md-4">
<div class="thumbnail"> 
<a href = "item.php?id={$row['IDproduct']}"><img class = "item" width='150' src="../resources/$productImage" alt=""></a>
<div class="caption">
<h4 class="pull-right">	&#82;{$row['productPrice']}</h4>
<h4><a href="item.php?id={$row['IDproduct']}">{$row['productName']}</a>
</h4>
<p>{$row['productCaption']}</p>
<a class="btn btn-primary" target="_blank" href="item.php?id={$row['IDproduct']}">View Item</a>
<a class="btn btn-success" target="_blank" href="cart.php?add={$row['IDproduct']}">Add to Cart</a>
</div>


</div>
</div>
DELIMITER;

        echo $products;
    }
}

function get_categories()
{//Gets categories from the database and displays the different types
    if(isset($_SESSION['user'])){

        $welcome = <<<DELIMITER
        <h3>Welcome {$_SESSION['user']}</h3>


DELIMITER;
echo $welcome;
    }

    $query = query("SELECT * FROM categories");

    confirm($query);

    while ($row = fetch_array($query)) {
        $categories_links = <<<DELIMITER

<a href='category.php?id={$row['IDcat']}' class='list-group-item'>{$row['title_cat']}</a>

DELIMITER;

        echo $categories_links;
    }
}



function get_catitems()
{//Gets Products specific to their categories and displays it when you click on a category type
    $query =  query("SELECT * FROM products WHERE productCate = " . escape_string($_GET['id']) . " ");

    confirm($query);

    while ($row = fetch_array($query)) {
        $productImage = showImage($row['productImage']);
        $products = <<<DELIMITER
<div class="col-sm-4 col-lg-4 col-md-4">
<div class="thumbnail"> 
<a href = "item.php?id={$row['IDproduct']}"><img width='150' src="../resources/{$productImage}" alt=""></a>
<div class="caption">
<h4 class="pull-right">	&#82;{$row['productPrice']}</h4>
<h4><a href="item.php?id={$row['IDproduct']}">{$row['productName']}</a>
</h4>
<p>{$row['productCaption']}</p>
<a class="btn btn-primary" target="_blank" href="item.php?id={$row['IDproduct']}">View Item</a>
<a class="btn btn-success" target="_blank" href="cart.php?add={$row['IDproduct']}">Add to Cart</a>
</div>


</div>
</div>
DELIMITER;

        echo $products;
    }
}

//Back end Functions

function get_shopitems()
{//Displays products
    $query =  query("SELECT * FROM products");

    confirm($query);

    while ($row = fetch_array($query)) {
        $productImage = showImage($row['productImage']);
        $products = <<<DELIMITER
<div class="col-sm-4 col-lg-4 col-md-4">
<div class="thumbnail"> 
<a href = "item.php?id={$row['IDproduct']}"><img src="../resources/{$productImage}" alt="" width='100'></a>
<div class="caption">
<h4 class="pull-right">	&#82;{$row['productPrice']}</h4>
<h4><a href="item.php?id={$row['IDproduct']}">{$row['productName']}</a>
</h4>
<p>{$row['productCaption']}</p>
<a class="btn btn-primary" target="_blank" href="item.php?id={$row['IDproduct']}">View Item</a>
<a class="btn btn-success" target="_blank" href="cart.php?add={$row['IDproduct']}">Add to Cart</a>
</div>


</div>
</div>
DELIMITER;

        echo $products;
    }
}


function loginCust()
{//The user login function which checks if the username and password are correct before allowing the user in.
    if (isLoggedIn()) {

        header('location: index.php');
    }
    if (isset($_POST['submit'])) {
        $username = escape_string($_POST['username']);
        $password = escape_string($_POST['password']);


        $query = query("SELECT * FROM users WHERE username = '{$username}' AND password = '{$password}'");
        confirm($query);

        if (mysqli_num_rows($query) == 0) {
            setMessage("Your Password or Username are Incorrect.");
            redirect("login.php");
            echo "Your Password or Username are Incorrect.";
        } else {
            $_SESSION['username'] = $username;
            $_SESSION['user'] = $username; // put logged in user in session
            $_SESSION['userType'] = query("SELECT userType from users where username = '{$username}'");

            redirect("index.php");
            session_start();
        }
    }
}


function sendMsg()
{//Sends message via email. Does not work as of now due to some php thing
    if (isset($_POST['submit'])) {

        $to = "aaaallie0@gmail.com";

        $name = $_POST['name'];
        $subject = $_POST['subject'];
        $email = $_POST['email'];
        $message = $_POST['message'];

        $headers = "From: {$name} {$email}";

        $result = mail($to, $subject, $message, $headers);

        if (!$result) {

            setMessage("Your Message has been sent.");
            redirect("contact.php");
        } else {
            setMessage("Your Message has been sent.");
        }
    }
}

function registerCust()
{//Registers a user into the database and logs them in
    $username = "";
    $email    = "";
    // call these variables with the global keyword to make them available in function
    global $db, $errors, $username, $email;

    // receive all input values from the form. Call the escape_string() function
    // defined below to escape form values
    $username =  escape_string($_POST['username']);
    $email =  escape_string($_POST['email']);
    $password_1 =  escape_string($_POST['password_1']);
    $password_2 =  escape_string($_POST['password_2']);
  

    // form validation: ensure that the form is correctly filled
    if (empty($username)) {
        array_push($errors, "Username is required");
        setMessage("Username is required!");
    }
    if (empty($email)) {
        array_push($errors, "Email is required");
        setMessage("Email is required!");
    }
    if (empty($password_1)) {
        array_push($errors, "Password is required");
        setMessage("Password is required!");
    }
   
    if ($password_1 != $password_2) {
        array_push($errors, "The two passwords do not match");
        setMessage("Passwords do not match");
    }

    // register user if there are no errors in the form
    if (count($errors) == 0) {
        $password = $password_1; 

        if (isset($_POST['userType'])) {
            $userType = escape_string($_POST['userType']);
            $query = query("INSERT INTO users (username, userEmail, userType, password) 
                      VALUES('$username', '$email', '$userType', '$password')");
            confirm($query);

            $_SESSION['success']  = "New user successfully created!!";
            header('location: index.php');
        } else {
            $query = query("INSERT INTO users (username, userEmail, userType, password) 
                      VALUES('$username', '$email', 'user', '$password')");
            confirm($query);



            $_SESSION['user'] = $username; // put logged in user in session
            $_SESSION['userType'] = query("SELECT userType from users where username = '{$username}'");
            $userType = $_SESSION['userType'];
            $_SESSION['success']  = "You are now logged in";
            header('location: index.php');
        }
    }
}
if (isset($_POST['register_btn'])) {
    registerCust();
}


function isLoggedIn()
{//checks if a user is logged in
    if (isset($_SESSION['user'])) {
        return true;
    } else {
        return false;
    }
}
function isAdmin()
{//checks user type
    if (isset($_SESSION['user']) && $_SESSION['userType'] == 'admin') {
        return true;
    } else {
        return false;
    }
}

function orderAdd(){
//adding into orders database table
if(isset($_POST['paybtn'])){
$total = $_SESSION['itemTotal'];
$user = $_SESSION['user'];
$address = escape_string($_POST['address']);
$name = escape_string($_POST['fullname']);
  $query=  query("INSERT INTO orders (orderTotal, orderUser, orderAddress, fullname, orderStatus) VALUES ('$total','$user','$address', '$name', 'pending')");
  
  confirm($query);
  setMessage("Order Recieved.");
  redirect("thanks.php");
}
}
//Admin stuffs

function adminProducts()
{//Shows all items in the database to the admin
    $query =  query("SELECT * FROM products");

    confirm($query);

    while ($row = fetch_array($query)) {

        $category = showCatTitle($row['productCate']);
        $productImage = showImage($row['productImage']);

        $products = <<<DELIMITER
        <tr>
        <td>{$row['IDproduct']}</td>
        <td>{$row['productName']}<br>
        <a href="index.php?edit_products.php"><img width='150' src="../../resources/$productImage" alt=""> </a>
        </td> 
        <td> {$row['productCate']}</td>
        <td>{$row['productPrice']}</td>
        <td>{$row['productQuantity']}</td>
        <td><a class = "btn btn-danger" href="../../resources/templates/back/deleteProduct.php?id={$row['IDproduct']}"><span class="glyphicon glyphicon-remove"></span></td>
    </tr>


</div>
</div>
DELIMITER;

        echo $products;
    }
}


function addProduct()
{//Adds a products to the database

    if (isset($_POST['publish'])) {

        echo "Hey";

        $productName = escape_string($_POST['productName']);
        $productCate = escape_string($_POST['productCate']);
        $productPrice = escape_string($_POST['productPrice']);
        $productDesc = escape_string($_POST['productDesc']);
        $productCaption = escape_string($_POST['productCaption']);
        $productQuantity = escape_string($_POST['productQuantity']);
        $productImage = escape_string($_FILES['file']['name']);
        $imageTemp = escape_string($_FILES['file']['tmpname']);

        move_uploaded_file($imageTemp, TEMPLATE_IMAGE . $productImage);

        $query = query("INSERT INTO products(productName, productCate, productPrice, productDesc, productCaption, productQuantity, productImage) VALUES ('{$productName}', '{$productCate}', '{$productPrice}', '{$productDesc}', '{$productCaption}', '{$productQuantity}', '{$productImage}')");
        confirm($query);
        setMessage("Added Product");
        redirect("index.php?products");
    }
}

function showCatAdmin()
{//shows the different categories to the admin when adding a products
    $query = query("SELECT * FROM categories");
    confirm($query);

    while ($row = fetch_array($query)) {
        $categories = <<<DELIMITER

<option value ="{$row['IDcat']}">{$row['title_cat']}</option>

DELIMITER;
        echo $categories;
    }
}
function showCatTitle($IDcategory)
{//Shows title of category
    $query = query("SELECT * FROM categories WHERE IDcat = '{$IDcategory}'");
    confirm($query);

    while ($row = fetch_array($query)) {
        return $row['title_cat'];
    }
}
function showImage($pic)
{//shows the items images
    global $images;

    return $images . DS . $pic;
}
function catAdmin()
{//Shows the different categories to the admin
    $query = query("SELECT * FROM categories");

    confirm($query);

    while ($row = fetch_array($query)) {

        $IDcat = $row['IDcat'];
        $catTitle = $row['title_cat'];

        $category = <<<DELIMITER

<tr>
 <td>{$IDcat}</td>
 <td>{$catTitle}</Td>
 <td><a class = "btn btn-danger" href="../../resources/templates/back/deleteCat.php?id={$row['IDcat']}"><span class="glyphicon glyphicon-remove"></span></td>
</tr>

DELIMITER;

        echo $category;
    }
}

function addCatAdmin()
{//Adds a new category to the database
    if (isset($_POST['addCat'])) {


        $catTitle = escape_string($_POST['catTitle']);
        if (empty($catTitle) || $catTitle == " ") {
            setMessage("Cannot insert blank category.");
        } else {
            $query = query("INSERT INTO categories(title_cat) VALUES ('{$catTitle}')");
            confirm($query);
            setMessage("Category Added.");
            redirect("categories.php");
        }
    }
}

function userAdmin()
{//Shows all users to the admin
    $query = query("SELECT * FROM users WHERE userType='user'");

    confirm($query);

    while ($row = fetch_array($query)) {

        $IDuser = $row['IDuser'];
        $username = $row['username'];
        $email = $row['userEmail'];


        $users = <<<DELIMITER

<tr>
 <td>{$IDuser}</td>
 <td>{$username}</Td>
 <td>{$email}</Td>
 <td><a class = "btn btn-danger" href="../../resources/templates/back/deleteUser.php?id={$row['IDuser']}"><span class="glyphicon glyphicon-remove"></span></td>
</tr>

DELIMITER;

        echo $users;
    }
}

function ordersAdmin(){
    //Shows all orders in the database
    $query = query("SELECT * FROM orders");

    confirm($query);

    while ($row = fetch_array($query)) {

        $IDorder = $row['IDorder'];
        $username = $row['orderUser'];
        $address = $row['orderAddress'];
        $name = $row['fullname'];
        $total = $row['orderTotal'];
        $status = $row['orderStatus'];


        $orders = <<<DELIMITER

<tr>
 <td>{$IDorder}</td>
 <td>{$username}</Td>
 <td>{$name}</Td>
 <td>{$status}</Td>
 <td>{$total}</Td>
 <td>{$address}</Td>
 
</tr>

DELIMITER;

        echo $orders;
    }
}
function reportsAdmin(){
    //shows all reports in the database
    $query = query("SELECT * FROM reports");

    confirm($query);

    while ($row = fetch_array($query)) {

        $IDreport = $row['IDreport'];
        $IDproduct = $row['IDProduct'];
        $price = $row['productPrice'];
        $quantity = $row['productQuantity'];
               $reports = <<<DELIMITER

<tr>
 <td>{$IDreport}</td>
 <td>{$IDproduct}</Td>
 <td>{$price}</Td>
 <td>{$quantity}</Td>
  
</tr>
DELIMITER;

        echo $reports;
    }
}