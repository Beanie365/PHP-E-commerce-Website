-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2020 at 04:05 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `IDcat` int(11) NOT NULL,
  `title_cat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`IDcat`, `title_cat`) VALUES
(1, 'Wheels'),
(2, 'Batteries'),
(3, 'Vinyl'),
(4, 'Wheel Decoration'),
(5, 'Car Accessories'),
(6, 'Tyres'),
(7, 'Paint'),
(12, 'Beans');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `IDorder` int(11) NOT NULL,
  `orderTotal` float NOT NULL,
  `orderUser` varchar(11) NOT NULL,
  `orderAddress` varchar(255) NOT NULL,
  `fullname` varchar(11) NOT NULL,
  `orderStatus` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`IDorder`, `orderTotal`, `orderUser`, `orderAddress`, `fullname`, `orderStatus`) VALUES
(1, 590, 'rico', '318 8th Avenue Lotus River', 'Rocky Road', 'pending'),
(2, 1590, 'rico', '14 SenRoad 12312', 'Blue Bunny', 'pending'),
(3, 5980, 'rico', '318 8th Avenue Lotus River', 'Sandy', 'pending'),
(4, 1230, 'rico', '', '', 'pending'),
(5, 2950, 'admin', 'somewhere in some place', 'Ndai', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `IDproduct` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `productCate` int(11) NOT NULL,
  `productPrice` float NOT NULL,
  `productQuantity` int(11) NOT NULL,
  `productDesc` text NOT NULL,
  `productImage` varchar(255) NOT NULL,
  `productCaption` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`IDproduct`, `productName`, `productCate`, `productPrice`, `productQuantity`, `productDesc`, `productImage`, `productCaption`) VALUES
(19, '13\" Tyres', 6, 590, 10, '13\" Tyres for your cars. The most love your wheels will get!', '13inch Tyres.jpg', '13\" High Quality Tyres'),
(20, '14\" Tyres', 6, 640, 10, '14\" Tyres for your cars. The most love your wheels will get!', '14inch Tyres.jpg', '14\" High Quality Tyres for your cars.'),
(21, '15\" Tyres', 6, 680, 10, '15\" Tyres for your cars. The most love your wheels will get!', '15inch Tyres.jpg', '15\" High Quality Tyres for your car.'),
(22, '16\" Tyres', 6, 740, 10, '16\" Tyres for your cars. The most love your wheels will get!', '16inch Tyres.jpg', '16\" High Quality Tyres.'),
(23, '17\" Tyres', 6, 800, 10, '17\" Tyres for your cars. The most love your wheels will get!', '17inch Tyres.jpg', '17\" High Quality Tyres'),
(24, '18\" Tyres', 6, 880, 10, '18\" Tyres for your cars. The most love your wheels will get!', '18inch Tyres.jpg', '18\" High Quality Tyres'),
(25, '19\" Tyres', 6, 940, 10, '19\" Tyres for your cars. The most love your wheels will get!', '19inch Tyres.jpg', '19\" High Quality Tyres'),
(26, '20\" Tyres', 6, 1000, 10, '20\" Tyres for your cars. The most love your wheels will get!', '20inch Tyres.jpg', '20\" High Quality Tyres'),
(27, 'Isaac Vinyl Sticker 200x200mm', 3, 120, 15, 'Binding of Isaac Vinyl Sticker. Adorable sticker for cars.', 'Vinyl3.png', 'Binding of Isaac Vinyl Sticker. Adorable sticker for cars.'),
(28, 'Baby on Board Owl Sticker 150x200mm', 3, 80, 10, 'Cute Baby onBoard Window Vinyl.\r\n \r\nSize 150x200', 'Vinyl4.jpg', 'Baby on Board Sticker'),
(29, 'Cool Vinyl Sticker', 3, 80, 40, 'Cool! Bunny and Bear Sticker Vinyls. \r\n\r\nSize 400mmx 100mm', 'Vinyl5.jpg', 'Cool! Bunny and Bear Sticker Vinyls. '),
(30, 'Winnie The Pooh Vinyl', 3, 130, 12, 'Winnie the Pooh  Car Vinyl Sticker\r\n\r\n300mmx300mm\r\n\r\nCute Sticker.', 'Vinyl6.jpg', 'Winnie the Pooh  Car Vinyl Sticker'),
(31, 'Mr Burns Mermaid Vinyl', 3, 200, 15, 'Mr Burns Simpsons Vinyl Sticker\r\n\r\nSize: 400x400mm\r\n\r\nHigh Quality', 'Vinyl7.jpg', 'Mr Burns Simpsons Vinyl Sticker'),
(32, 'Hello Vinyl', 3, 75, 10, 'Hello Vinyl Car Sticker\r\n\r\nSize: 250mm x 100mm', 'Vinyl8.jpg', 'Hello Vinyl Car Sticker'),
(33, 'Ford Vinyl Sticker', 3, 80, 11, 'Ford Vinyl Sticker for Cars\r\n\r\nsize 150mmx150mm', 'Vinyl1.jpg', 'Ford Vinyl Sticker for Cars\r\n'),
(34, 'Race Stripes Vinyl Sticker', 3, 60, 12, 'Race Stripes with number 53 Vinyl Sticker\r\n\r\nSize: 300mmx300mm', 'Vinyl2.jpg', 'Race Stripes with number 53 Vinyl Sticker'),
(35, 'Horse Shoe Vinyl Sticker', 3, 88, 13, 'Black Horse Shoe Vinyl Sticker\r\n\r\nSize: 400mmx400mm', 'Vinyl9.png', 'Black Horse Shoe Vinyl Sticker\r\nfor Cars'),
(36, 'Battery Duracel 619', 2, 500, 15, 'Duracel Battery 619', 'Battery2.jpg', 'Duracel Battery 619'),
(37, 'Battery Atlas 613', 2, 450, 12, 'Car Battery Atlas 613', 'Battery4.jpg', 'Car Battery Atlas 613'),
(38, 'Battery Atlas 618', 2, 400, 13, 'Battery Atlas 618', 'Battery1.jpg', 'Battery Atlas 618'),
(39, 'Battery Atlas 631', 2, 560, 11, 'Battery Atlas 631', 'Battery3.jpg', 'Battery Atlas 631'),
(40, 'BSS Wheel Decal', 4, 350, 11, 'BSS Wheel Decal\r\n\r\nContains 4 Units', 'Decal1.jpg', 'BSS Wheel Decal'),
(41, 'Class 76 Decal', 4, 250, 16, 'Classic number 76 Wheel Decal\r\n\r\nContains 4 Units', 'Decal2.jpg', 'Classic number 76 Wheel Decal'),
(42, 'Audi Wheel Decal', 4, 400, 6, 'Audi Car Brand Wheel Decal\r\n\r\nContains 4 Units', 'Decal3.jpg', 'Audi Car Brand Wheel Decal'),
(43, 'Byblos Wheel Decal', 4, 100, 7, 'Byblos Wheel Decoration Stickers\r\n\r\nContains 4 Units', 'Decal4.jpg', 'Byblos Wheel Decoration Stickers\r\n'),
(44, 'ATS Wheel Decal', 4, 120, 11, 'ATS Wheel Sticker Decoration\r\n\r\nContains 4 Units', 'Decal5.jpg', 'ATS Wheel Sticker Decoration'),
(45, 'Renault Wheel Sticker', 4, 80, 12, 'Renault Wheel Decoration Sticker\r\n\r\nContains 4 units.', 'Decal6.jpg', 'Renault Wheel Decoration Sticker'),
(46, 'Borbet Wheel Decal', 4, 300, 10, 'Borbet Wheel Sticker Decal\r\n\r\nContains 8 units', 'Decal7.jpg', 'Borbet Wheel Sticker Decal'),
(47, 'Pentagon Wheel Cap', 4, 200, 10, 'Pentagon Mag Wheel Cap\r\n\r\nContains 4 Units', 'Decal8.jpg', 'Pentagon Mag Wheel Cap'),
(48, 'Alloy Wheel 13\"', 1, 1500, 10, 'Alloy Wheel 13\"\r\nContains 4 Wheels', '13inch1.jpg', 'Alloy Wheel 13\"'),
(49, 'Alloy Wheel 13\"', 1, 2400, 13, 'Alloy Wheel 13\"\r\nContains 4 Wheels', '13inch2.jpg', 'Alloy Wheel 13\"'),
(50, '14\" Alloy Wheel', 1, 2300, 11, 'Alloy Wheel in size 14 Inches\r\n\r\nContains 4 Units', '14inch1.jpg', 'Alloy Wheel in size 14 Inches'),
(51, '14\" Alloy Wheel', 1, 1700, 11, 'Alloy Wheel in size 14 Inches\r\n\r\nContains 4 Units', '14inch2.jpg', 'Alloy Wheel in size 14 Inches'),
(52, '15\" Alloy Wheel', 1, 3500, 14, '15\" Alloy Wheel\r\n\r\nContains 4 units', '15inch1.jpg', ''),
(53, '15\" Alloy Wheel', 1, 4500, 16, '15\" Alloy Wheel\r\n\r\nContains 4 units', '15inch2.jpg', '15\" Alloy Wheel'),
(54, '16\" Alloy Wheels', 1, 3700, 16, '16\" Alloy Wheels\r\n\r\nContains 4 Units', '16inch1.jpg', '16\" Alloy Wheels\r\n'),
(55, '16\" Alloy Wheels', 1, 1900, 12, '16\" Alloy Wheels\r\n\r\nContains 4 Units', '16inch2.jpg', '16\" Alloy Wheels'),
(56, '17\" Alloy Wheels', 1, 4500, 14, '17\" Alloy Wheels\r\n\r\nContains 4 Units.', '17inch1.jpg', '17\" Alloy Wheels\r\n'),
(57, '17\" Alloy Wheels', 1, 2300, 12, '17\" Alloy Wheels\r\n\r\nContains 4 Units.', '17inch2.jpg', '17\" Alloy Wheels\r\n'),
(58, '18\" Alloy Wheels\r\n', 1, 2500, 12, '18\" Alloy Wheels\r\n\r\nContains 4 Units', '18inch1.jpg', '18\" Alloy Wheels'),
(59, '18\" Alloy Wheels', 1, 3400, 13, '18\" Alloy Wheels\r\n\r\nContains 4 Units', '18inch2.jpg', '18\" Alloy Wheels'),
(60, '19\" Alloy Wheel', 1, 5500, 12, '19\" Alloy Wheel\r\n\r\nContains 4 Units', '19inch1.jpg', '19\" Alloy Wheel'),
(61, '19\" Alloy Wheel', 1, 4700, 14, '19\" Alloy Wheel\r\n\r\nContains 4 Units', '19inch2.jpg', '19\" Alloy Wheel'),
(62, '20\" Alloy Wheels', 1, 3700, 12, '20 Inch Alloy Wheels.\r\n\r\nContains 4 Units', '20inch1.jpg', '20\" Alloy Wheels'),
(63, '20\" Alloy Wheels', 1, 3400, 12, '20\" Alloy Wheels\r\n\r\nContains 4 Units', '20inch2.jpg', '20\" Alloy Wheels'),
(64, 'Chrome Lights', 5, 900, 11, 'Chrome Lights for Side of car\r\n\r\nMedium Sized\r\n\r\nContains 2 Units', 'acc1.jpg', 'Chrome Lights for Side of car'),
(65, 'Chrome Side Pieces', 5, 550, 16, 'Contains $ Units of Chrome Strips for Cars', 'acc3.jpg', 'Chrome Side Pieces'),
(66, 'Holder Straps', 5, 250, 11, 'Holder Straps\r\n\r\nContains 2 Units', 'acc2.jpg', 'Holder Straps For External Use'),
(67, 'TearDrop Lights', 5, 750, 12, 'TearDrop Lights\r\n\r\nReplaces Side Lights\r\n\r\nContains 2 Units', 'acc4.jpg', 'TearDrop Lights for Cars'),
(68, 'SprayPaint- Black', 7, 450, 11, 'Duplicolor Spray Paint\r\n\r\nBlack\r\n\r\n500ml', 'paint.jpg', 'Duplicolor Spray Paint'),
(69, 'SprayPaint- Yellow', 7, 750, 11, 'Duplicolor Spray Paint\r\n\r\nYellow\r\n\r\n500ml', 'paint.jpg', 'Duplicolor Spray Paint'),
(70, 'SprayPaint- Brown', 7, 250, 11, 'Duplicolor Spray Paint\r\n\r\nBrown\r\n\r\n500ml', 'paint.jpg', 'Duplicolor Spray Paint'),
(71, 'SprayPaint- Green', 7, 400, 11, 'Duplicolor Spray Paint\r\n\r\nGreen\r\n\r\n500ml', 'paint.jpg', 'Duplicolor Spray Paint'),
(72, 'SprayPaint- Blue', 7, 550, 11, 'Duplicolor Spray Paint\r\n\r\nBlue\r\n\r\n500ml', 'paint.jpg', 'Duplicolor Spray Paint'),
(73, 'Tyre', 6, 450, 5, 'A tyre', '', 'Have no no fear'),
(74, 'OX ', 3, 150, 7, 'STicker', 'XO.png', 'STicker');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `IDreport` int(11) NOT NULL,
  `IDProduct` int(11) NOT NULL,
  `productPrice` float NOT NULL,
  `productQuantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`IDreport`, `IDProduct`, `productPrice`, `productQuantity`) VALUES
(1, 2, 150, 1),
(2, 2, 150, 1),
(3, 1, 400, 1),
(4, 2, 150, 1),
(5, 1, 400, 2),
(6, 20, 640, 1),
(7, 20, 640, 1),
(8, 20, 640, 2),
(9, 20, 640, 1),
(10, 19, 590, 2),
(11, 29, 80, 1),
(12, 19, 590, 2),
(13, 29, 80, 1),
(14, 19, 590, 1),
(15, 24, 880, 1),
(16, 27, 120, 1),
(17, 40, 350, 1),
(18, 22, 740, 3),
(19, 42, 400, 1),
(20, 23, 800, 1),
(21, 22, 740, 7),
(22, 19, 590, 1),
(23, 20, 640, 1),
(24, 19, 590, 5);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `IDuser` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `userEmail` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `userType` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`IDuser`, `username`, `userEmail`, `password`, `userType`) VALUES
(1, 'rico', 'rico@hotmail.com', '123', 'user'),
(2, 'edwin', 'support@ediwniaz.com', '456', 'user'),
(14, 'admin', 'admin123@gmail.com', 'securepassword123', 'admin'),
(15, 'WhiteBread', 'Whitebread@gmail.com', 'thewhitestofbread', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`IDcat`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`IDorder`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`IDproduct`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`IDreport`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`IDuser`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `IDcat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `IDorder` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `IDproduct` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `IDreport` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `IDuser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
